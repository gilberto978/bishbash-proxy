# BishBash Proxy

This is a simple proxy to call OpenAI's API safely from Uncody.

## Deploy on Vercel
- Import this repo into Vercel
- Add environment variable `OPENAI_API_KEY`
- Deploy
